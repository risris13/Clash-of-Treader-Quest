# Clash of Trader Quest (PWA)

Jurnal trading bergaya game. Paket ini siap diunggah ke GitHub Pages lalu bisa diinstal sebagai aplikasi Android.

## Isi paket
- `index.html`: aplikasinya (semua gambar, font, dan karakter sudah ada di dalamnya)
- `manifest.json`: nama, warna, dan ikon aplikasi
- `sw.js`: service worker agar aplikasi bisa dipakai tanpa internet
- `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png`, `favicon.png`: ikon naga hitam putih
- `alt-logo-*.png`: ikon alternatif memakai logo Clash of Trader Quest
- `.nojekyll`: file kosong supaya GitHub Pages menyajikan folder `.well-known`

## A. Unggah ke GitHub
1. Buat akun di github.com, lalu New repository.
2. Nama repository: `usernamemu.github.io` (ganti dengan username GitHub kamu persis). Pilih Public.
3. Ekstrak zip ini. Di repository, pilih Add file, lalu Upload files, dan pilih SEMUA file (kecuali README.md kalau tidak mau). Tekan Commit changes.
4. File `.nojekyll` kadang tidak ikut terpilih karena tersembunyi. Kalau belum ada di repository: Add file, Create new file, ketik nama `.nojekyll`, lalu Commit.

## B. Aktifkan GitHub Pages
1. Settings, lalu Pages.
2. Source: Deploy from a branch. Branch: `main`, folder `/ (root)`. Save.
3. Tunggu 1 sampai 2 menit. Alamatnya: `https://usernamemu.github.io`

## C. Pasang di HP
Buka alamat itu di Chrome Android, tekan menu (tiga titik), lalu "Instal aplikasi" atau "Tambahkan ke layar utama". Aplikasi berjalan layar penuh dan bisa dibuka tanpa internet.

## D. Jadikan APK (opsional)
1. Buka pwabuilder.com, tempel alamat dari langkah B, tekan Start.
2. Pilih paket Android. Isi nama aplikasi, package ID (contoh `com.namamu.clashoftrader`), dan versi. Generate, lalu unduh zip-nya.
3. Simpan file keystore dari zip itu di tempat aman. Tanpa file itu kamu tidak bisa memperbarui aplikasi yang sama.
4. Instal file APK di HP (izinkan "Instal dari sumber tidak dikenal"). Untuk Play Store pakai file AAB.

## E. Hilangkan bilah alamat Chrome di APK
PWABuilder memberi file `assetlinks.json`. Di repository: Add file, Create new file, ketik nama `.well-known/assetlinks.json` (tanda `/` otomatis membuat folder), tempel isinya, lalu Commit.

## F. Memperbarui aplikasi
1. Ganti file yang berubah di repository (Add file, Upload files, timpa nama yang sama).
2. Buka `sw.js` dan naikkan angka versi pada baris `var CACHE='cotq-v1'` (jadi `cotq-v2`, dan seterusnya) agar HP memuat versi baru.

## Mengganti ikon ke logo
Di `manifest.json`, ubah `icon-192.png` menjadi `alt-logo-192.png`, `icon-512.png` menjadi `alt-logo-512.png`, dan `icon-maskable-512.png` menjadi `alt-logo-maskable-512.png`. Lalu naikkan versi di `sw.js` (langkah F).

## Catatan
- **Data jurnal:** tersimpan di browser per alamat. Alamat baru berarti mulai kosong. Gunakan Backup di versi lama, lalu Impor di versi ini. Lakukan Backup berkala.
- **Kurs rupiah:** diambil otomatis sekali sehari dari ExchangeRate-API saat ada internet. Kalau gagal, kurs terakhir tetap dipakai dan bisa diatur manual.
- **Font Minecraft:** milik Mojang dan tidak bebas lisensi. Untuk pemakaian pribadi aman, tapi ganti dengan font bebas lisensi sebelum aplikasi dibagikan publik atau masuk Play Store.
